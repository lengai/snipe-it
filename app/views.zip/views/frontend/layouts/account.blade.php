@extends('frontend/layouts/default')

{{-- Page content --}}
@section('content')
<div class="row">
    <div class="col-md-12">
        @yield('account-content')
    </div>
</div>
@stop
